# Treatments page (/treatments) redesign: one-go prompt

Reference: `reference/treatments-v7.html` (open it in a browser and match it). Port it into the existing `/treatments` route using the site's tokens, Fraunces + Figtree and the header and footer. Do not show prices anywhere.

Images: copy `public/images/treatments/` from this zip. They are all real images from the live dentalkrafts.com treatment pages. Frame every image with `object-fit:cover` and never zoom it.

## Structure
1. **Hero:** two columns.
   - **Left:** the eyebrow, H1 "Every treatment, *explained.*", the lead paragraph, two buttons ("Help me choose" and "Ask on WhatsApp"), and a facts row: 23 treatments · 2 specialists · 2 clinics in Gurugram.
   - **Right:** a 3-photo collage that replaces the empty green box. The tall tile is `expert-in-pediatric` (both doctors) with `object-position:18% center`; the other two are `dental-implants-banner` and `smile-makeover-banner`, each with a pill caption.
2. **Sticky jump bar:** 6 pills, each with a round thumbnail, the group name and a count. The active pill gets highlighted while you scroll (IntersectionObserver).
3. **Six group sections**, alternating paper and white. Each one has:
   - a 16:10 feature photo (it swaps sides on alternate sections), "01 / 06", an H2, a lead line, and a "Led by" pill;
   - then a grid of **photo cards** (4:3 image, title, one line, "Read more →"). These replace the old rows with repeated icons.
   - **Grid columns:** 4 cards = 4 columns, 3 cards = 3, 2 cards = 2, and a single card is a wide horizontal card.
4. **"Not sure what you need?"** in a peach panel with "Book a visit" and WhatsApp buttons.

## Image map (card → file in /images/treatments/)
| Group (feature image) | Cards |
|---|---|
| Replace missing teeth (types-of-dental-implants) | Dental implants: dental-implants · All-on-4: fixed-bridge-supported-by-4-8 · Dentures: dentures · Full-mouth rehab: advantages-of-all-on-four |
| Save a tooth (rct_causes-of-root-canal) | Root canal: rool-canal-treatment · Fillings: dental-fillings · Crowns & bridges: dental-crowns |
| Smile design (cosmetic-dentist-banner) | Smile makeover: smile-makeover-banner · Veneers: dental-veneers · Whitening: in-office-vs-at-home-teeth · Cosmetic: cosmetic-dentistry |
| Straighten teeth (best-invisible-aligners) | Braces: teeth-braces-banner · Invisalign: invisalign-banner |
| Kids and teens (expert-in-pediatric) | Pediatric dentistry: paediatric-dentist-banner |
| Gums, surgery and urgent care (contact-us) | Gum disease: gum-disease-treatment · Laser: teeth-whitening-banner · Wisdom tooth: post-care-tips · Cleaning: teeth-cleaning · General: why-is-dental-implant · Emergency: rct_painless-root-canal · Toothache: why-do-teeth-get |

## Phone (≤560px)
- Cards become horizontal rows: a 38% image on the left and the text on the right, clamped to 3 lines.
- The jump bar scrolls sideways.
- There must be no horizontal page scroll.

## Avoid
Class collisions: don't use `.ph`, `.cta`, `.rel`, `.sc`, `.in`, `.on` (except the jump-bar state), `.hrs` or `.cl` as global names. Prefix with `tr-` or use CSS modules.
